<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>Morning Starcrest Logistics Limited</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">
        <link rel="icon" href="/assets/img/kaiadmin/favicon.ico" type="image/x-icon"/>

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Poppins:wght@200;300;400;500;600&display=swap" rel="stylesheet">

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

        <!-- Libraries Stylesheet -->
        <link href="/front/lib/animate/animate.min.css" rel="stylesheet">
        <link href="/front/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


        <!-- Customized Bootstrap Stylesheet -->
        <link href="/front/css/bootstrap.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="/front/css/style.css" rel="stylesheet">
    </head>

    <body>

        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-secondary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Topbar Start -->
        @include("/frontend/header")
        <!-- Navbar & Hero End -->


        <!-- Carousel Start -->

        <!-- Carousel End -->

        <div class="container-fluid testimonial overflow-hidden py-5" >
        <div class="container">
            <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">

                <h5>Track Your Package</h5>
                <form autocomplete="off" action="/trackid" method="post">
                @csrf
                <div class="position-relative mx-auto rounded-pill" style="border: 1px solid #000;">

                    <input autocomplete="off" required maxlength="10" class="form-control border-0 rounded-pill w-100 py-3 ps-4 pe-5" placeholder="Enter Your Ticket ID"   type="text" name="id">
                    <button  type="submit" class="btn btn-primary rounded-pill position-absolute top-0 end-0 py-2 mt-2 me-2"  style="background-color:blue;">Track</button>
                </div>
              </form>
        </div>
        @if($message = Session:: get('track_error'))
                  <table align="center" width="100%" height="50" style="background-color: #ffcc99; padding:15px;margin-bottom:10px;">
                    <tr>
                      <td align="center">	{{$message}} </td>
                    </tr>
                  </table>

                {{  Session::forget('track_error'); }}
                  @endif
        <br><br>
        <div class="card-header">
            @foreach($pack as $box)
          <div class="card-title">Tracking Details - T.ID:  <strong>{{$box->tid}}</strong></div>
          @endforeach
        </div>
        <div class="card-body">
          @foreach($pack as $box)
          <strong>Date Ordered: {{$box->tdate}}</strong><br>
          Ref. ID: 0000{{$box->refid}}10230<br>
          Origin: {{$box->origin}}<br>
          Destination: {{$box->destination}}<br>
          Package Type: {{$box->ptype}}<br>
          Service Type: {{$box->stype}}<br>
          Status: <button style="background-color:blue; border:none; padding:5px; color:white;">Morning Star Warehouse</button><br>
          @endforeach

          <hr>
  @php
  $date = date('Y-m-d');
  @endphp
  @foreach($pack as $box)
  @if($box->sdate <= $date)

          <strong>On the {{$box->sdate}}</strong><br>
          Ref. ID: 0000{{$box->refid}}10230<br>
          Origin: {{$box->origin}}<br>
          Destination: {{$box->destination}}<br>
          Package Type: {{$box->ptype}}<br>
          Service Type: {{$box->stype}}<br>
          Status:  <button style="background-color:orange; border:none; padding:5px; color:white;">In Transit</button><br>
          @endif
          @endforeach

          <hr>
          @php
          $date = date('Y-m-d');
          @endphp
          @foreach($pack as $box)
          @if($box->edate <= $date)
          <strong>On the {{$box->edate}} - {{$box->time}}</strong><br>
          Ref. ID: 0000{{$box->refid}}10230<br>
          Origin: {{$box->origin}}<br>
          Destination: {{$box->destination}}<br>
          Package Type: {{$box->ptype}}<br>
          Service Type: {{$box->stype}}<br>
          Status: <button style="background-color:green; border:none; padding:5px; color:white;">{{$box->status}}</button><br>
          <br>

            @endif
          @endforeach

        </div>
        </div>
      </div>
        <!-- About Start -->

        <!-- About End -->


        <!-- Services Start -->
        <div class="container-fluid service overflow-hidden py-5">
            <div class="container">
                <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="sub-style">
                        <h5 class="sub-title text-primary px-3">Explore Our Services</h5>
                    </div>
                    <h1 class="display-5 mb-4">Enabling Your Logistics Successfully</h1>
                    <p class="mb-0">We have the expertise to make your supply chain work for you.</p>
                </div>
                <div class="row g-4">
                    <div class="col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="service-item">
                            <div class="service-inner">
                                <div class="service-img">
                                    <img src="/front/img/service-1.jpg" class="img-fluid w-100 rounded" alt="Image">
                                </div>
                                <div class="service-title">
                                    <div class="service-title-name">
                                        <div class="bg-primary text-center rounded p-3 mx-5 mb-4">
                                            <a href="#" class="h4 text-white mb-0">Air Freight</a>
                                        </div>
                                        <a class="btn bg-light text-secondary rounded-pill py-3 px-5 mb-4" href="#">Explore More</a>
                                    </div>
                                    <div class="service-content pb-4">
                                        <a href="#"><h4 class="text-white mb-4 py-3">Air Freight</h4></a>
                                        <div class="px-4">
                                            <p class="mb-4">From express courier and logistics to warehousing and distribution.</p>
                                            <a class="btn btn-primary border-secondary rounded-pill py-3 px-5" href="#">Explore More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="service-item">
                            <div class="service-inner">
                                <div class="service-img">
                                    <img src="/front/img/service-2.jpg" class="img-fluid w-100 rounded" alt="Image">
                                </div>
                                <div class="service-title">
                                    <div class="service-title-name">
                                        <div class="bg-primary text-center rounded p-3 mx-5 mb-4">
                                            <a href="#" class="h4 text-white mb-0">Ocean Freight</a>
                                        </div>
                                        <a class="btn bg-light text-secondary rounded-pill py-3 px-5 mb-4" href="#">Explore More</a>
                                    </div>
                                    <div class="service-content pb-4">
                                        <a href="#"><h4 class="text-white mb-4 py-3">Ocean Freight</h4></a>
                                        <div class="px-4">
                                            <p class="mb-4">From express courier and logistics to warehousing and distribution.</p>
                                            <a class="btn btn-primary border-secondary rounded-pill text-white py-3 px-5" href="#">Explore More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="service-item">
                            <div class="service-inner">
                                <div class="service-img">
                                    <img src="/front/img/service-3.jpg" class="img-fluid w-100 rounded" alt="Image">
                                </div>
                                <div class="service-title">
                                    <div class="service-title-name">
                                        <div class="bg-primary text-center rounded p-3 mx-5 mb-4">
                                            <a href="#" class="h4 text-white mb-0">Road Freight</a>
                                        </div>
                                        <a class="btn bg-light text-secondary rounded-pill py-3 px-5 mb-4" href="#">Explore More</a>
                                    </div>
                                    <div class="service-content pb-4">
                                        <a href="#"><h4 class="text-white mb-4 py-3">Road Freight</h4></a>
                                        <div class="px-4">
                                            <p class="mb-4">From express courier and logistics to warehousing and distribution.</p>
                                            <a class="btn btn-primary border-secondary rounded-pill text-white py-3 px-5" href="#">Explore More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="service-item">
                            <div class="service-inner">
                                <div class="service-img">
                                    <img src="/front/img/service-5.jpg" class="img-fluid w-100 rounded" alt="Image">
                                </div>
                                <div class="service-title">
                                    <div class="service-title-name">
                                        <div class="bg-primary text-center rounded p-3 mx-5 mb-4">
                                            <a href="#" class="h4 text-white mb-0">Train Freight</a>
                                        </div>
                                        <a class="btn bg-light text-secondary rounded-pill py-3 px-5 mb-4" href="#">Explore More</a>
                                    </div>
                                    <div class="service-content pb-4">
                                        <a href="#"><h4 class="text-white mb-4 py-3">Train Freight</h4></a>
                                        <div class="px-4">
                                            <p class="mb-4">From express courier and logistics to warehousing and distribution.</p>
                                            <a class="btn btn-primary border-secondary rounded-pill text-white py-3 px-5" href="#">Explore More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="service-item">
                            <div class="service-inner">
                                <div class="service-img">
                                    <img src="/front/img/service-6.jpg" class="img-fluid w-100 rounded" alt="Image">
                                </div>
                                <div class="service-title">
                                    <div class="service-title-name">
                                        <div class="bg-primary text-center rounded p-3 mx-5 mb-4">
                                            <a href="#" class="h4 text-white mb-0">Customs Clearance</a>
                                        </div>
                                        <a class="btn bg-light text-secondary rounded-pill py-3 px-5 mb-4" href="#">Explore More</a>
                                    </div>
                                    <div class="service-content pb-4">
                                        <a href="#"><h4 class="text-white mb-4 py-3">Customs Clearance</h4></a>
                                        <div class="px-4">
                                            <p class="mb-4">From express courier and logistics to warehousing and distribution.</p>
                                            <a class="btn btn-primary border-secondary rounded-pill text-white py-3 px-5" href="#">Explore More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="service-item">
                            <div class="service-inner">
                                <div class="service-img">
                                    <img src="/front/img/service-7.jpg" class="img-fluid w-100 rounded" alt="Image">
                                </div>
                                <div class="service-title">
                                    <div class="service-title-name">
                                        <div class="bg-primary text-center rounded p-3 mx-5 mb-4">
                                            <a href="#" class="h4 text-white mb-0">Warehouse Solutions</a>
                                        </div>
                                        <a class="btn bg-light text-secondary rounded-pill py-3 px-5 mb-4" href="#">Explore More</a>
                                    </div>
                                    <div class="service-content pb-4">
                                        <a href="#"><h4 class="text-white mb-4 py-3">Warehouse Solutions</h4></a>
                                        <div class="px-4">
                                            <p class="mb-4">From express courier and logistics to warehousing and distribution.</p>
                                            <a class="btn btn-primary border-secondary rounded-pill text-white py-3 px-5" href="#">Explore More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Services End -->


        <!-- Testimonial Start -->

        <!-- Testimonial End -->


        <!-- Contact Start -->
        <div class="container-fluid contact overflow-hidden py-5">
            <div class="container pb-5">
                <div class="office">
                    <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="sub-style">
                            <h5 class="sub-title text-primary px-3">Worlwide Offices</h5>
                        </div>
                        <h1 class="display-5 mb-4">Explore Our Office Worldwide</h1>
                        <p class="mb-0">We have the expertise to make your supply chain work for you in all our locations worldwide</p>
                    </div>
                    <div class="row g-4 justify-content-center">
                        <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
                            <div class="office-item p-4">
                                <div class="office-img mb-4">
                                    <img src="/front/img/office-2.jpg" class="img-fluid w-100 rounded" alt="">
                                </div>
                                <div class="office-content d-flex flex-column">
                                    <h4 class="mb-2">Nigeria</h4>
                                    <a href="#" class="text-secondary fs-5 mb-2">+234 703 667 7412</a>
                                    <a href="#" class="text-muted fs-5 mb-2">contact@18morningstar.com</a>
                                    <p class="mb-0">123, First Floor, 123 St Roots Terrace, Los Angeles 90010 Unitd States of America.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.3s">
                            <div class="office-item p-4">
                                <div class="office-img mb-4">
                                    <img src="/front/img/office-1.jpg" class="img-fluid w-100 rounded" alt="">
                                </div>
                                <div class="office-content d-flex flex-column">
                                    <h4 class="mb-2">Canada</h4>
                                    <a href="#" class="text-secondary fs-5 mb-2">+234 703 667 7412</a>
                                    <a href="#" class="text-muted fs-5 mb-2">contact@18morningstar.com</a>
                                    <p class="mb-0">3, Bish. (Dr) Festus Odusola St, Freedom Gate Bustop, Idimu-Ikotun road, Lagos</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.5s">
                            <div class="office-item p-4">
                                <div class="office-img mb-4">
                                    <img src="/front/img/office-3.jpg" class="img-fluid w-100 rounded" alt="">
                                </div>
                                <div class="office-content d-flex flex-column">
                                    <h4 class="mb-2">United Kingdom</h4>
                                    <a href="#" class="text-secondary fs-5 mb-2">+234 703 667 7412</a>
                                    <a href="#" class="text-muted fs-5 mb-2">contact@18morningstar.com</a>
                                    <p class="mb-0">3, Bish. (Dr) Festus Odusola St, Freedom Gate Bustop, Idimu-Ikotun road, Lagos.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.7s">
                            <div class="office-item p-4">
                                <div class="office-img mb-4">
                                    <img src="/front/img/office-4.jpg" class="img-fluid w-100 rounded" alt="">
                                </div>
                                <div class="office-content d-flex flex-column">
                                    <h4 class="mb-2">USA</h4>
                                    <a href="#" class="text-secondary fs-5 mb-2">+234 703 667 7412</a>
                                    <a href="#" class="text-muted fs-5 mb-2">contact@18morningstar.com</a>
                                    <p class="mb-0">3, Bish. (Dr) Festus Odusola St, Freedom Gate Bustop, Idimu-Ikotun road, Lagos</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Contact End -->


        <!-- Footer Start -->
          @include("/frontend/footer")
        <!-- Footer End -->


        <!-- Copyright Start -->

        <!-- Copyright End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-primary btn-lg-square back-to-top"><i class="fa fa-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/front/lib/wow/wow.min.js"></script>
    <script src="/front/lib/easing/easing.min.js"></script>
    <script src="/front/lib/waypoints/waypoints.min.js"></script>
    <script src="/front/lib/owlcarousel/owl.carousel.min.js"></script>


    <!-- Template Javascript -->
    <script src="/front/js/main.js"></script>
    </body>

</html>
